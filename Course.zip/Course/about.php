<?php

session_start();
include("connections.php");
?>
<?php include 'header/header.php';?>

<!-- About Heading -->
<div class="about-container-1">
    <h1>Meet The Team</h1>
    <p>Our core team member</p>
</div>


<div class="container1">
    <div class="about-container">
        <img src="img/sk1.jpg" alt ="Shaikat" width="200px" height="200px" style="border-radius: 50%;">
            <div class="align-items">
            <h3>MD. Shahriar Islam Shaikat</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium ab quisquam incidunt maxime! Temporibus laborum nemo nostrum labore numquam adipisci perspiciatis.</p>
    
            </div>
            
        </div>  
    <div class="about-container">
            <img  src="img/circle-cropped (1).png" alt ="Monir" width="200px" height="200px">
            <div class="align-items">
            <h3>Monirul Alam</h3>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Porro totam vitae, animi voluptate molestiae explicabo inventore labore deleniti corrupti ratione?</p>
    
            </div>
        </div> 
    <div class="about-container">
        <img src="img/circle-cropped.png" alt ="Faisal" width="200px" height="200px">
        <div class="align-items">
        <h3>Faisal Mohammad Shah</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi illum hic, atque, autem aspernatur, ipsum debitis similique facilis tempore quis aliquam minus sunt necessitatibus?</p>

        </div>
        
    </div>   



</div>
<!-- footer -->
<?php include 'footer.php'; ?>
    
        
</body>
</html>